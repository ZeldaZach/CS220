#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *p = (int *) malloc(100000*0x1000);
    return 0;
}
