#include <stdio.h>

int main()
{
    int arr[10000];
    return sizeof(10000);
}
